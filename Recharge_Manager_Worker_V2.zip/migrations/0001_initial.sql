CREATE TABLE IF NOT EXISTS clients (
  id TEXT PRIMARY KEY,
  endpoint TEXT NOT NULL UNIQUE,
  subscription_json TEXT NOT NULL,
  customers_json TEXT NOT NULL DEFAULT '[]',
  settings_json TEXT NOT NULL DEFAULT '{"daysBefore":4,"time":"09:00"}',
  leader_json TEXT NOT NULL DEFAULT '""',
  sent_json TEXT NOT NULL DEFAULT '{}',
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_clients_updated_at ON clients(updated_at);
