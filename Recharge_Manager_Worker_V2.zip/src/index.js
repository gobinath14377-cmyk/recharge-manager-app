import webpush from "web-push";

const PUBLIC_VAPID_KEY = "BDTHXBeoSmb7RLl14KT9Dg40DhhLwDwNpQZu8AO9inCpjz6HP8HDEeG5Hoc2Wm8rkGVEy3aInbTYmpHTJImV7b4";

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store"
    }
  });
}

async function clientId(endpoint) {
  const d = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(endpoint));
  return [...new Uint8Array(d)].map(b => b.toString(16).padStart(2, "0")).join("");
}

function localParts() {
  const p = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Kolkata",
    year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", hourCycle: "h23"
  }).formatToParts(new Date());
  const g = t => p.find(x => x.type === t)?.value || "00";
  return {
    date: `${g("year")}-${g("month")}-${g("day")}`,
    time: `${g("hour")}:${g("minute")}`
  };
}

function diffDays(target, today) {
  if (!target) return NaN;
  return Math.round((new Date(`${target}T00:00:00Z`) - new Date(`${today}T00:00:00Z`)) / 86400000);
}

function parseJSON(value, fallback) {
  try { return JSON.parse(value); } catch { return fallback; }
}

async function ensureSchema(env) {
  await env.DB.prepare(`
    CREATE TABLE IF NOT EXISTS clients (
      id TEXT PRIMARY KEY,
      endpoint TEXT NOT NULL UNIQUE,
      subscription_json TEXT NOT NULL,
      customers_json TEXT NOT NULL DEFAULT '[]',
      settings_json TEXT NOT NULL DEFAULT '{"daysBefore":4,"time":"09:00"}',
      leader_json TEXT NOT NULL DEFAULT '""',
      sent_json TEXT NOT NULL DEFAULT '{}',
      updated_at TEXT NOT NULL
    )
  `).run();
  await env.DB.prepare("CREATE INDEX IF NOT EXISTS idx_clients_updated_at ON clients(updated_at)").run();
}

async function handleSync(request, env) {
  if (!env.DB) return json({ ok: false, error: "D1 binding DB is not configured" }, 500);
  if (request.method !== "POST") return new Response("Method Not Allowed", { status: 405 });

  try {
    await ensureSchema(env);
    const b = await request.json();
    if (!b?.subscription?.endpoint) return json({ ok: false, error: "Missing subscription" }, 400);

    const endpoint = String(b.subscription.endpoint);
    const id = await clientId(endpoint);
    const existing = await env.DB.prepare("SELECT sent_json FROM clients WHERE id = ?").bind(id).first();
    const sent = existing?.sent_json || "{}";

    await env.DB.prepare(`
      INSERT INTO clients
        (id, endpoint, subscription_json, customers_json, settings_json, leader_json, sent_json, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET
        endpoint=excluded.endpoint,
        subscription_json=excluded.subscription_json,
        customers_json=excluded.customers_json,
        settings_json=excluded.settings_json,
        leader_json=excluded.leader_json,
        updated_at=excluded.updated_at
    `).bind(
      id,
      endpoint,
      JSON.stringify(b.subscription),
      JSON.stringify(Array.isArray(b.customers) ? b.customers : []),
      JSON.stringify(b.settings || { daysBefore: 4, time: "09:00" }),
      JSON.stringify(b.leader || ""),
      sent,
      new Date().toISOString()
    ).run();

    return json({ ok: true });
  } catch (e) {
    return json({ ok: false, error: String(e) }, 500);
  }
}

async function sendReminders(env) {
  if (!env.DB) throw new Error("D1 binding DB is not configured");
  if (!env.VAPID_PRIVATE_KEY) throw new Error("VAPID_PRIVATE_KEY secret is not configured");

  await ensureSchema(env);
  webpush.setVapidDetails(
    env.VAPID_SUBJECT || "mailto:gobinath14377@gmail.com",
    PUBLIC_VAPID_KEY,
    env.VAPID_PRIVATE_KEY
  );

  const now = localParts();
  const result = await env.DB.prepare("SELECT * FROM clients").all();

  for (const row of result.results || []) {
    const subscription = parseJSON(row.subscription_json, null);
    if (!subscription?.endpoint) continue;

    const customers = parseJSON(row.customers_json, []);
    const settings = parseJSON(row.settings_json, { daysBefore: 4, time: "09:00" });
    const sent = parseJSON(row.sent_json, {});

    if (now.time < String(settings.time || "09:00")) continue;

    const daysBefore = Number(settings.daysBefore ?? 4);
    const due = customers.filter(c => diffDays(c.nextDate, now.date) === daysBefore);
    const fresh = due.filter(c => !sent[`${c.id}|${c.nextDate}`]);
    if (!fresh.length) continue;

    const body = fresh
      .map(c => `${c.name} - ${c.phone} • ${c.nextDate} அன்று recharge முடியும்`)
      .join("\n");

    try {
      await webpush.sendNotification(subscription, JSON.stringify({
        title: fresh.length === 1
          ? `🔔 ${fresh[0].name} Recharge Reminder`
          : `🔔 ${fresh.length} Recharge Reminders`,
        body,
        tag: "recharge-reminder",
        url: "/"
      }));

      fresh.forEach(c => {
        sent[`${c.id}|${c.nextDate}`] = new Date().toISOString();
      });

      await env.DB.prepare(
        "UPDATE clients SET sent_json=?, updated_at=? WHERE id=?"
      ).bind(JSON.stringify(sent), new Date().toISOString(), row.id).run();
    } catch (e) {
      if (e?.statusCode === 404 || e?.statusCode === 410) {
        await env.DB.prepare("DELETE FROM clients WHERE id=?").bind(row.id).run();
      }
    }
  }
}

export default {
  async fetch(request, env) {
    const u = new URL(request.url);

    if (u.pathname === "/api/vapid-public-key" && request.method === "GET") {
      return json({ publicKey: PUBLIC_VAPID_KEY });
    }

    if (u.pathname === "/api/sync") {
      return handleSync(request, env);
    }

    return env.ASSETS.fetch(request);
  },

  async scheduled(controller, env, ctx) {
    ctx.waitUntil(sendReminders(env));
  }
};
