# Recharge Manager — Cloudflare Worker

This package deploys the existing Recharge Manager app as a Cloudflare Worker with Static Assets, D1 storage, and a one-minute Cron Trigger for background reminders.

## Included
- Existing Recharge Manager UI and localStorage key preserved
- PWA manifest + service worker + 192/512 icons
- Worker API: `/api/sync` and `/api/vapid-public-key`
- D1 database binding: `recharge-manager-db`
- One-minute reminder Cron Trigger
- GitHub Actions deployment workflow
- No private VAPID key included

## GitHub Actions secrets
Create these repository secrets:
- `CLOUDFLARE_ACCOUNT_ID` = your Cloudflare account ID
- `CLOUDFLARE_API_TOKEN` = Cloudflare API token with permission to deploy Workers

## Cloudflare Worker secret
After the first deployment, add this Worker secret:
- `VAPID_PRIVATE_KEY` = the private VAPID key kept outside this repository

Optional Worker variable:
- `VAPID_SUBJECT` = `mailto:gobinath14377@gmail.com`

The public VAPID key is intentionally embedded in the Worker because it is public by design.

## D1
The Worker creates its `clients` table automatically on the first sync/cron request. The SQL migration is also included in `migrations/0001_initial.sql` as a backup/manual migration.
