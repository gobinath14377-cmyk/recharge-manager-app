# Recharge Manager — Cloudflare Worker

This package contains the full Recharge Manager app, PWA assets, Cloudflare Worker API, D1 binding, and one-minute reminder cron.

## One-time Cloudflare setup
1. Run the D1 migration `migrations/0001_init.sql` against `recharge-manager-db`.
2. Add Worker secrets: `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY`, `VAPID_SUBJECT`.
3. For GitHub Actions add repository secrets `CLOUDFLARE_API_TOKEN` and `CLOUDFLARE_ACCOUNT_ID`.
4. Deploy with `npx wrangler deploy` or the included GitHub Action.

Never put the VAPID private key in GitHub or this ZIP.
