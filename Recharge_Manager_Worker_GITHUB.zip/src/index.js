import webpush from "web-push";

const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status,
  headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" }
});

function clientId(endpoint) {
  let h = 2166136261;
  for (let i = 0; i < endpoint.length; i++) {
    h ^= endpoint.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(16) + "-" + endpoint.length.toString(16);
}

function localParts() {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Kolkata", year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", hourCycle: "h23"
  }).formatToParts(new Date());
  const get = t => parts.find(p => p.type === t)?.value || "00";
  return { date: `${get("year")}-${get("month")}-${get("day")}`, time: `${get("hour")}:${get("minute")}` };
}

function diffDays(target, today) {
  if (!target) return NaN;
  const a = new Date(`${today}T00:00:00Z`);
  const b = new Date(`${target}T00:00:00Z`);
  return Math.round((b - a) / 86400000);
}

async function sync(request, env) {
  const body = await request.json();
  if (!body?.subscription?.endpoint) return json({ ok: false, error: "Missing subscription" }, 400);
  const endpoint = String(body.subscription.endpoint);
  const id = clientId(endpoint);
  await env.DB.prepare(`INSERT INTO clients
    (id,endpoint,subscription_json,customers_json,settings_json,leader_json,sent_json,updated_at)
    VALUES(?,?,?,?,?,?,?,?)
    ON CONFLICT(id) DO UPDATE SET endpoint=excluded.endpoint, subscription_json=excluded.subscription_json,
    customers_json=excluded.customers_json, settings_json=excluded.settings_json, leader_json=excluded.leader_json,
    sent_json=excluded.sent_json, updated_at=excluded.updated_at`)
    .bind(id, endpoint, JSON.stringify(body.subscription), JSON.stringify(Array.isArray(body.customers) ? body.customers : []),
      JSON.stringify(body.settings || { daysBefore: 4, time: "09:00" }), JSON.stringify(body.leader || ""),
      JSON.stringify(body.sent || {}), new Date().toISOString()).run();
  return json({ ok: true });
}

async function cron(env) {
  const pub = env.VAPID_PUBLIC_KEY;
  const priv = env.VAPID_PRIVATE_KEY;
  if (!pub || !priv) return;
  webpush.setVapidDetails(env.VAPID_SUBJECT || "mailto:admin@example.com", pub, priv);
  const now = localParts();
  const rows = await env.DB.prepare("SELECT * FROM clients").all();
  for (const row of rows.results || []) {
    let data;
    try {
      data = {
        subscription: JSON.parse(row.subscription_json),
        customers: JSON.parse(row.customers_json || "[]"),
        settings: JSON.parse(row.settings_json || "{}"),
        sent: JSON.parse(row.sent_json || "{}")
      };
    } catch { continue; }
    const settings = data.settings || { daysBefore: 4, time: "09:00" };
    if (now.time < String(settings.time || "09:00")) continue;
    const due = (data.customers || []).filter(c => diffDays(c.nextDate, now.date) === Number(settings.daysBefore ?? 4));
    const fresh = due.filter(c => !data.sent?.[`${c.id}|${c.nextDate}`]);
    if (!fresh.length) continue;
    const body = fresh.map(c => `${c.name} - ${c.phone} • ${c.nextDate} அன்று recharge முடியும்`).join("\n");
    try {
      await webpush.sendNotification(data.subscription, JSON.stringify({
        title: fresh.length === 1 ? `🔔 ${fresh[0].name} Recharge Reminder` : `🔔 ${fresh.length} Recharge Reminders`,
        body, tag: "recharge-reminder", url: "/"
      }));
      const sent = data.sent || {};
      for (const c of fresh) sent[`${c.id}|${c.nextDate}`] = new Date().toISOString();
      await env.DB.prepare("UPDATE clients SET sent_json=?, updated_at=? WHERE id=?")
        .bind(JSON.stringify(sent), new Date().toISOString(), row.id).run();
    } catch (e) {
      const code = e?.statusCode;
      if (code === 404 || code === 410) await env.DB.prepare("DELETE FROM clients WHERE id=?").bind(row.id).run();
    }
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    try {
      if (url.pathname === "/api/vapid-public-key" && request.method === "GET") return json({ publicKey: env.VAPID_PUBLIC_KEY || "" });
      if (url.pathname === "/api/sync" && request.method === "POST") return await sync(request, env);
      if (url.pathname === "/api/health" && request.method === "GET") return json({ ok: true, service: "recharge-manager" });
      return env.ASSETS.fetch(request);
    } catch (e) {
      return json({ ok: false, error: String(e) }, 500);
    }
  },
  async scheduled(_event, env, ctx) { ctx.waitUntil(cron(env)); }
};
