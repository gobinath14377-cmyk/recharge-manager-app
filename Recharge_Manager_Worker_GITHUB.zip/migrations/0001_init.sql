CREATE TABLE IF NOT EXISTS clients (
  id TEXT PRIMARY KEY,
  endpoint TEXT NOT NULL,
  subscription_json TEXT NOT NULL,
  customers_json TEXT NOT NULL DEFAULT '[]',
  settings_json TEXT NOT NULL DEFAULT '{}',
  leader_json TEXT NOT NULL DEFAULT '""',
  sent_json TEXT NOT NULL DEFAULT '{}',
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_clients_endpoint ON clients(endpoint);
